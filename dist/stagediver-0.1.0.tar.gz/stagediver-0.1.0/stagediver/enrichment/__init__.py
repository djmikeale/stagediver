"""
Data enrichment functionality.
Contains:
- Artist metadata collection
- Genre classification
- Similar artist detection
- Data quality checks
"""
