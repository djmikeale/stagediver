"""
Web interface for Stagediver.
"""
