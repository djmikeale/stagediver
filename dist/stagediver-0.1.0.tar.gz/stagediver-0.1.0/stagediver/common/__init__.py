"""
Common utilities and shared functionality.
Contains:
- Shared exceptions
- Base classes
- Common type definitions
"""
