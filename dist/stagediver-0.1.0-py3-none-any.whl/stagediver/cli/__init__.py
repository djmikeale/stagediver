"""
CLI interface for Stagediver.
"""
